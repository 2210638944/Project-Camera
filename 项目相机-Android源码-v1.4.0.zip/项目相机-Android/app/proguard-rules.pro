# Keep file for release builds (minify disabled for now).
