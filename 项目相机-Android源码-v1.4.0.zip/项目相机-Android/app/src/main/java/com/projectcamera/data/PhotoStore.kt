package com.projectcamera.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

/**
 * 照片与导出统一存放在存储根目录 /项目相机/ 下。
 * 兼容旧版本（Pictures/项目相机/...、Download/项目相机/...）写入 MediaStore 的元数据读取。
 */
object PhotoStore {
    const val BASE_DIR = "项目相机"
    const val AUTHORITY = "com.projectcamera.fileprovider"

    private val isQ: Boolean get() = Build.VERSION.SDK_INT >= 29

    fun sanitize(name: String): String {
        val cleaned = name.replace(Regex("[/\\\\:*?\"<>|]"), "_").trim()
        return cleaned.ifEmpty { "未命名" }
    }

    /** 新格式目录相对路径，例如 项目相机/A座装修工程/一层水电/ */
    fun relativeDirFor(names: List<String>): String =
        BASE_DIR + "/" + names.joinToString("/") { sanitize(it) } + "/"

    /** 存储根目录下的项目相机目录 */
    fun rootDir(context: Context): File =
        File(Environment.getExternalStorageDirectory(), BASE_DIR)

    private fun relChain(relDir: String): String = relDir.removePrefix("$BASE_DIR/")

    /** 根目录是否可创建且可写（用于触发「所有文件访问」授权） */
    fun storageReady(context: Context): Boolean {
        return try {
            val dir = rootDir(context)
            if (!dir.exists() && !dir.mkdirs()) return false
            val probe = File(dir, ".probe_" + System.currentTimeMillis())
            probe.createNewFile()
            probe.delete()
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- 解析 / 读取 ----------

    private fun queryMedia(
        context: Context,
        collection: Uri,
        relDir: String,
        fileName: String
    ): Uri? {
        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=?"
        context.contentResolver.query(
            collection, projection, selection, arrayOf(relDir, fileName), null
        )?.use { c ->
            if (c.moveToFirst()) {
                return Uri.withAppendedPath(collection, c.getLong(0).toString())
            }
        }
        return null
    }

    /** 照片可访问 Uri：旧版 MediaStore 前缀走 content uri，新版根目录文件走 FileProvider */
    fun resolveUri(context: Context, relDir: String, fileName: String): Uri? {
        return when {
            relDir.startsWith("Pictures/") ->
                queryMedia(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, relDir, fileName)
            relDir.startsWith("Download/") ->
                queryMedia(context, MediaStore.Downloads.EXTERNAL_CONTENT_URI, relDir, fileName)
            else -> {
                val f = File(File(rootDir(context), relChain(relDir)), fileName)
                if (f.exists()) {
                    try {
                        FileProvider.getUriForFile(context, AUTHORITY, f)
                    } catch (e: Exception) {
                        Uri.fromFile(f)
                    }
                } else null
            }
        }
    }

    /** 目录内全部照片：文件名 + 拍摄时间，新→旧 */
    fun listPhotos(context: Context, relDir: String): List<Pair<String, Long>> {
        if (relDir.startsWith("Pictures/") || relDir.startsWith("Download/")) {
            val collection = if (relDir.startsWith("Pictures/"))
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            else
                MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val list = mutableListOf<Pair<String, Long>>()
            val projection = arrayOf(
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DATE_ADDED
            )
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH}=?"
            context.contentResolver.query(
                collection, projection, selection, arrayOf(relDir),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (c.moveToNext()) {
                    var t = c.getLong(iDate)
                    if (t <= 0) t = c.getLong(iAdded) * 1000
                    list += c.getString(iName) to t
                }
            }
            return list
        }
        val dir = File(rootDir(context), relChain(relDir))
        return dir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".jpg") }
            ?.map { it.name to it.lastModified() }
            ?.sortedByDescending { it.second } ?: emptyList()
    }

    // ---------- 写入 / 删除 ----------

    fun savePhoto(
        context: Context,
        bitmap: Bitmap,
        relDir: String,
        fileName: String,
        takenAt: Long,
        quality: Int = 92
    ): Boolean {
        if (!storageReady(context)) return false
        return try {
            val dir = File(rootDir(context), relChain(relDir))
            if (!dir.exists() && !dir.mkdirs()) return false
            val f = File(dir, fileName)
            FileOutputStream(f).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            }
            f.setLastModified(takenAt)
            MediaScannerConnection.scanFile(
                context, arrayOf(f.absolutePath), arrayOf("image/jpeg"), null
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    fun deletePhoto(context: Context, relDir: String, fileName: String) {
        if (relDir.startsWith("Pictures/") || relDir.startsWith("Download/")) {
            val collection = if (relDir.startsWith("Pictures/"))
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            else
                MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=?"
            context.contentResolver.delete(collection, selection, arrayOf(relDir, fileName))
            return
        }
        val f = File(File(rootDir(context), relChain(relDir)), fileName)
        if (f.exists()) f.delete()
        try {
            context.contentResolver.delete(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                "${MediaStore.MediaColumns.DATA}=?",
                arrayOf(f.absolutePath)
            )
        } catch (e: Exception) {
        }
    }

    fun openStream(context: Context, relDir: String, fileName: String): InputStream? {
        if (relDir.startsWith("Pictures/") || relDir.startsWith("Download/")) {
            val uri = resolveUri(context, relDir, fileName) ?: return null
            return context.contentResolver.openInputStream(uri)
        }
        val f = File(File(rootDir(context), relChain(relDir)), fileName)
        return if (f.exists()) FileInputStream(f) else null
    }

    fun loadBitmap(context: Context, relDir: String, fileName: String, maxDim: Int = 1600): Bitmap? {
        return try {
            val bytes = openStream(context, relDir, fileName)?.use { it.readBytes() } ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > maxDim || bounds.outHeight / sample > maxDim) sample *= 2
            BitmapFactory.decodeByteArray(
                bytes, 0, bytes.size,
                BitmapFactory.Options().apply { inSampleSize = sample }
            )
        } catch (e: Exception) {
            null
        }
    }

    // ---------- 导出 PDF / ZIP ----------

    /** 导出到 根目录/项目相机/<subDir>/，返回目标文件 */
    fun exportToRoot(context: Context, subDir: String, displayName: String, mime: String, file: File): File? {
        if (!storageReady(context)) return null
        return try {
            val dir = File(File(rootDir(context), subDir), "")
            if (!dir.exists() && !dir.mkdirs()) return null
            val dst = File(dir, displayName)
            file.inputStream().use { ins -> FileOutputStream(dst).use { ins.copyTo(it) } }
            MediaScannerConnection.scanFile(context, arrayOf(dst.absolutePath), arrayOf(mime), null)
            dst
        } catch (e: Exception) {
            null
        }
    }
}
