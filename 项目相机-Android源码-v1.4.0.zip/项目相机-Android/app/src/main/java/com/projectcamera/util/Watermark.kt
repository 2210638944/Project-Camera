package com.projectcamera.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.projectcamera.data.WmSettings

object Watermark {

    fun lines(projectName: String, settings: WmSettings, takenAt: Long, loc: LocInfo?): List<String> {
        val l = mutableListOf<String>()
        if (settings.showProject) l += projectName
        if (settings.showTime) l += Fmt.dateTime(takenAt)
        if (settings.showLocation && loc?.address != null) l += loc.address
        if (settings.showLatLng && loc != null) l += loc.latLng
        return l
    }

    fun apply(src: Bitmap, lines: List<String>, settings: WmSettings): Bitmap {
        if (lines.isEmpty()) return src
        val w = src.width
        val base = when (settings.fontSize) {
            0 -> 0.028
            1 -> 0.038
            else -> 0.052
        }
        val textSize = w * base.toFloat()
        val margin = textSize * 0.85f
        val lineGap = textSize * 1.5f

        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            this.textSize = textSize
            isFakeBoldText = true
            if (settings.shadow) {
                setShadowLayer(textSize * 0.22f, 0f, textSize * 0.1f, Color.BLACK)
            }
        }

        val alignRight = settings.position == 1 || settings.position == 3
        val alignTop = settings.position == 2 || settings.position == 3
        val baseX = if (alignRight) w - margin else margin
        val baseY = if (alignTop) {
            margin + textSize
        } else {
            out.height - margin - (lines.size - 1) * lineGap
        }

        lines.forEachIndexed { i, line ->
            val x = if (alignRight) baseX - paint.measureText(line) else baseX
            canvas.drawText(line, x, baseY + i * lineGap, paint)
        }
        return out
    }
}
