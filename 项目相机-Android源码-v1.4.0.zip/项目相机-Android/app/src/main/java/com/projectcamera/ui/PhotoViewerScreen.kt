package com.projectcamera.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.projectcamera.AppData
import com.projectcamera.data.PhotoStore
import com.projectcamera.util.Fmt
import com.projectcamera.util.ShareExport

@Composable
fun PhotoViewerScreen(
    projectId: String,
    startIndex: Int,
    dataVersion: Int,
    onDataChanged: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val repo = AppData.repo
    val photos = remember(projectId, dataVersion) { repo.photosOf(projectId) }
    if (photos.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val pagerState = rememberPagerState(initialPage = startIndex.coerceIn(0, photos.lastIndex)) { photos.size }
    var deleteOpen by remember { mutableStateOf(false) }
    val current = photos[pagerState.currentPage]

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val meta = photos[page]
            val bmp by produceState<Bitmap?>(initialValue = null, meta.fileName) {
                value = PhotoStore.loadBitmap(context, meta.relativeDir, meta.fileName, 2048)
            }
            if (bmp != null) {
                Image(
                    bitmap = bmp!!.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .background(Color(0x66000000))
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = Color.White)
            }
            Text(
                Fmt.dateTime(current.takenAt),
                Modifier
                    .weight(1f)
                    .padding(start = 8.dp),
                color = Color.White
            )
            IconButton(onClick = { deleteOpen = true }) {
                Icon(Icons.Default.Delete, contentDescription = "删除", tint = Color.White)
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .background(Color(0x66000000))
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val locLine = current.wmLines.lastOrNull { it.contains("°N") || it.contains("°E") }
            if (locLine != null) {
                Icon(
                    IconLocation,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(Modifier.width(6.dp))
            }
            Text(
                locLine ?: "拍摄于 ${Fmt.dateTime(current.takenAt)}",
                Modifier.weight(1f),
                color = Color.White
            )
            IconButton(onClick = {
                PhotoStore.resolveUri(context, current.relativeDir, current.fileName)
                    ?.let { ShareExport.sharePhoto(context, it) }
            }) {
                Icon(Icons.Default.Share, contentDescription = "分享", tint = Color.White)
            }
        }
    }

    if (deleteOpen) {
        DeleteConfirmDialog(
            title = "删除照片？",
            body = "将从项目与系统相册中删除该照片。",
            onCancel = { deleteOpen = false },
            onConfirm = {
                val meta = photos[pagerState.currentPage]
                PhotoStore.deletePhoto(context, meta.relativeDir, meta.fileName)
                repo.removePhoto(projectId, meta.fileName)
                onDataChanged()
                deleteOpen = false
            }
        )
    }
}
