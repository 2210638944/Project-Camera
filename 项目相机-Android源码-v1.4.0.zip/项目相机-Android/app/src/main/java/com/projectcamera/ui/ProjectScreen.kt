package com.projectcamera.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.projectcamera.AppData
import com.projectcamera.PhotoMeta
import com.projectcamera.ProjectNode

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProjectScreen(
    projectId: String,
    dataVersion: Int,
    onDataChanged: () -> Unit,
    onBack: () -> Unit,
    onOpenCamera: () -> Unit,
    onOpenProject: (String) -> Unit,
    onOpenViewer: (Int) -> Unit
) {
    val repo = AppData.repo
    val project = repo.find(projectId)
    if (project == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val children = remember(projectId, dataVersion) { repo.childrenOf(projectId) }
    val photos = remember(projectId, dataVersion) { repo.photosOf(projectId) }

    var menuOpen by remember { mutableStateOf(false) }
    var addOpen by remember { mutableStateOf(false) }
    var renameOpen by remember { mutableStateOf(false) }
    var renameValue by remember { mutableStateOf(project.name) }
    var deleteOpen by remember { mutableStateOf(false) }
    var newSubOpen by remember { mutableStateOf(false) }
    var newSubInput by remember { mutableStateOf("") }
    var exportMode by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            AppTopBar(
                title = project.name,
                onBack = onBack,
                actions = {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "更多")
                    }
                }
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 96.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        Text(
                            "${photos.size} 张照片 · ${children.size} 个子项目",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 2.dp, vertical = 6.dp)
                        )
                        if (children.isNotEmpty()) {
                            Text(
                                "子项目",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 2.dp, vertical = 6.dp)
                            )
                            SubProjectRow(children, onOpenProject)
                            Spacer(Modifier.height(10.dp))
                        }
                        Text(
                            "照片",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 2.dp, vertical = 6.dp)
                        )
                    }
                }
                items(photos, key = { it.fileName }) { meta ->
                    PhotoCell(meta, onClick = { onOpenViewer(photos.indexOf(meta)) })
                }
            }
        }

        FloatingActionButton(
            onClick = { addOpen = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(18.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "添加")
        }
    }

    if (menuOpen) {
        ProjectMenuDialog(
            project = project,
            onDismiss = { menuOpen = false },
            onRename = {
                renameValue = project.name
                renameOpen = true
            },
            onExport = { mode -> exportMode = mode },
            onDelete = { deleteOpen = true }
        )
    }

    if (addOpen) {
        AlertDialog(
            onDismissRequest = { addOpen = false },
            title = { Text("添加到项目", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .combinedClickable(onClick = { addOpen = false; onOpenCamera() })
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(shape = RoundedCornerShape(11.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)) {
                            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                                Icon(IconCamera, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("拍摄照片", fontWeight = FontWeight.SemiBold)
                            Text(
                                "进入相机，按当前水印设置自动添加",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .combinedClickable(onClick = { addOpen = false; newSubInput = ""; newSubOpen = true })
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(shape = RoundedCornerShape(11.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)) {
                            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                                Icon(IconFolderPlus, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("新建子项目", fontWeight = FontWeight.SemiBold)
                            Text(
                                "在项目内创建子项目，可继续嵌套",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { addOpen = false }) { Text("取消") }
            }
        )
    }

    if (renameOpen) {
        RenameDialog(
            initial = renameValue,
            onValueChange = { renameValue = it },
            onCancel = { renameOpen = false },
            onConfirm = {
                val n = renameValue.trim()
                if (n.isNotEmpty()) {
                    repo.rename(projectId, n)
                    onDataChanged()
                }
                renameOpen = false
            }
        )
    }

    if (deleteOpen) {
        DeleteConfirmDialog(
            title = "删除项目？",
            body = "将删除「${project.name}」及其中 ${photos.size} 张照片（含全部子项目）。此操作不可恢复。",
            onCancel = { deleteOpen = false },
            onConfirm = {
                repo.deleteProject(projectId)
                onDataChanged()
                onBack()
            }
        )
    }

    if (newSubOpen) {
        CreateProjectDialog(
            value = newSubInput,
            onValueChange = { newSubInput = it },
            title = "新建子项目",
            onCancel = { newSubOpen = false },
            onConfirm = {
                val n = newSubInput.trim()
                if (n.isNotEmpty()) {
                    repo.createProject(n, projectId)
                    onDataChanged()
                }
                newSubOpen = false
            }
        )
    }

    exportMode?.let { mode ->
        ExportFlowDialog(projectId = projectId, mode = mode, onClose = { exportMode = null })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SubProjectRow(children: List<ProjectNode>, onOpenProject: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        children.forEach { sub ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .width(140.dp)
                    .combinedClickable(onClick = { onOpenProject(sub.id) })
                    .padding(1.dp)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)) {
                        Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) {
                            Icon(IconFolder, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            sub.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                        Text(
                            "${AppData.repo.photoCountOf(sub.id)} 张",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PhotoCell(meta: PhotoMeta, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(6.dp))
            .combinedClickable(onClick = onClick),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        PhotoThumb(meta.relativeDir, meta.fileName, Modifier.fillMaxSize())
    }
}
