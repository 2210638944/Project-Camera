package com.projectcamera.data

import android.database.Cursor
import android.database.MatrixCursor
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import com.projectcamera.R
import java.io.File
import java.io.FileNotFoundException

/**
 * 把 存储根目录/项目相机/ 暴露为系统文件管理器（DocumentsUI）可浏览的文档树。
 * 用于「打开目录」：系统自带文件管理器直接定位到该目录。
 */
class ProjectDocsProvider : DocumentsProvider() {

    companion object {
        const val AUTHORITY = "com.projectcamera.provider"
        const val ROOT_ID = "root"

        private val DEFAULT_PROJECTION = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_SUMMARY,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_FLAGS,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED
        )
    }

    override fun onCreate(): Boolean = true

    private fun baseDir(): File = File(Environment.getExternalStorageDirectory(), PhotoStore.BASE_DIR)

    private fun fileFor(documentId: String): File {
        if (documentId == ROOT_ID || documentId.isEmpty()) return baseDir()
        val rel = documentId.removePrefix("$ROOT_ID/")
        return File(baseDir(), rel)
    }

    private fun docIdFor(childName: String, parentId: String): String =
        if (parentId == ROOT_ID) childName else "$parentId/$childName"

    private fun newDocumentCursor(
        documentId: String,
        f: File,
        projection: Array<out String>?
    ): Cursor {
        val cols = projection ?: DEFAULT_PROJECTION
        val c = MatrixCursor(cols)
        val row = c.newRow()
        val isDir = f.isDirectory
        row.add(Document.COLUMN_DOCUMENT_ID, documentId)
        row.add(Document.COLUMN_DISPLAY_NAME, f.name)
        row.add(Document.COLUMN_SUMMARY, null)
        row.add(Document.COLUMN_MIME_TYPE, if (isDir) Document.MIME_TYPE_DIR else "image/jpeg")
        row.add(
            Document.COLUMN_FLAGS,
            if (isDir) Document.FLAG_DIR_PREFERS_GRID else 0
        )
        row.add(Document.COLUMN_SIZE, if (isDir) null else f.length())
        row.add(Document.COLUMN_LAST_MODIFIED, f.lastModified())
        return c
    }

    override fun queryRoots(projection: Array<out String>?): Cursor {
        return try {
            val cols = projection ?: arrayOf(
                Root.COLUMN_ROOT_ID,
                Root.COLUMN_DOCUMENT_ID,
                Root.COLUMN_TITLE,
                Root.COLUMN_SUMMARY,
                Root.COLUMN_FLAGS,
                Root.COLUMN_ICON,
                Root.COLUMN_MIME_TYPES,
                Root.COLUMN_AVAILABLE_BYTES
            )
            val c = MatrixCursor(cols)
            val row = c.newRow()
            row.add(Root.COLUMN_ROOT_ID, ROOT_ID)
            row.add(Root.COLUMN_DOCUMENT_ID, ROOT_ID)
            row.add(Root.COLUMN_TITLE, "项目相机")
            row.add(Root.COLUMN_SUMMARY, "照片、PDF、ZIP 存储目录")
            row.add(Root.COLUMN_FLAGS, Root.FLAG_LOCAL_ONLY or Root.FLAG_SUPPORTS_IS_CHILD)
            row.add(Root.COLUMN_ICON, 0)
            row.add(Root.COLUMN_MIME_TYPES, "image/jpeg")
            row.add(Root.COLUMN_AVAILABLE_BYTES, baseDir().freeSpace)
            c
        } catch (e: Exception) {
            MatrixCursor(projection ?: arrayOf(Root.COLUMN_ROOT_ID))
        }
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor {
        return try {
            val f = fileFor(documentId)
            if (!f.exists()) throw FileNotFoundException("$documentId 不存在")
            newDocumentCursor(documentId, f, projection)
        } catch (e: Exception) {
            MatrixCursor(projection ?: DEFAULT_PROJECTION)
        }
    }

    override fun queryChildDocuments(
        parentDocumentId: String,
        projection: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        return try {
            val f = fileFor(parentDocumentId)
            if (!f.isDirectory) throw FileNotFoundException("不是目录")
            val cols = projection ?: DEFAULT_PROJECTION
            val c = MatrixCursor(cols)
            f.listFiles()
                ?.filter { !it.name.startsWith(".") }
                ?.sortedBy { it.name }
                ?.forEach { child ->
                    newDocumentCursor(docIdFor(child.name, parentDocumentId), child, projection)
                }
            c
        } catch (e: Exception) {
            MatrixCursor(projection ?: DEFAULT_PROJECTION)
        }
    }

    override fun getDocumentType(documentId: String): String {
        val f = fileFor(documentId)
        if (!f.exists()) throw FileNotFoundException()
        return if (f.isDirectory) Document.MIME_TYPE_DIR else "image/jpeg"
    }

    override fun isChildDocument(parentDocumentId: String, childDocumentId: String): Boolean =
        if (parentDocumentId == ROOT_ID) {
            childDocumentId != ROOT_ID && !childDocumentId.contains('/')
        } else {
            childDocumentId == parentDocumentId ||
                    childDocumentId.startsWith("$parentDocumentId/")
        }

    override fun openDocument(
        documentId: String,
        mode: String,
        signal: CancellationSignal?
    ): ParcelFileDescriptor {
        try {
            val f = fileFor(documentId)
            if (!f.exists() || !f.isFile) throw FileNotFoundException()
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        } catch (e: Exception) {
            throw FileNotFoundException()
        }
    }
}
