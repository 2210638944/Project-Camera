package com.projectcamera.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF2647E8)
val GreenOk = Color(0xFF16A34A)
val RedDanger = Color(0xFFE5484D)
val InkText = Color(0xFF101828)
val GrayText = Color(0xFF667085)
val BgLight = Color(0xFFF6F7F9)

private val LightColors = lightColorScheme(
    primary = BluePrimary,
    onPrimary = Color.White,
    background = BgLight,
    onBackground = InkText,
    surface = Color.White,
    onSurface = InkText,
    surfaceVariant = Color(0xFFEFF1F6),
    onSurfaceVariant = GrayText,
    secondary = GrayText,
    error = RedDanger
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FA6FF),
    onPrimary = Color(0xFF0B1440),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE8EAEF),
    surface = Color(0xFF1A1D24),
    onSurface = Color(0xFFE8EAEF),
    surfaceVariant = Color(0xFF23262E),
    onSurfaceVariant = Color(0xFFB4BAC6),
    secondary = Color(0xFF9AA2B4),
    error = Color(0xFFFF7A7F)
)

@Composable
fun ProjectCameraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
