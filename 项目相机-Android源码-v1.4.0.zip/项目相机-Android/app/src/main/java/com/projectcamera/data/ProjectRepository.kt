package com.projectcamera.data

import android.content.Context
import com.projectcamera.PhotoMeta
import com.projectcamera.ProjectNode
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectRepository(context: Context) {
    private val file = File(context.filesDir, "projects.json")
    private val projects = mutableListOf<ProjectNode>()
    private val photos = mutableListOf<PhotoMeta>()

    init { load() }

    private fun load() {
        if (!file.exists()) return
        try {
            val obj = JSONObject(file.readText())
            val pa = obj.getJSONArray("projects")
            for (i in 0 until pa.length()) {
                val o = pa.getJSONObject(i)
                projects += ProjectNode(
                    o.getString("id"),
                    o.getString("name"),
                    o.optString("parentId").ifEmpty { null },
                    o.getLong("createdAt")
                )
            }
            val ph = obj.getJSONArray("photos")
            for (i in 0 until ph.length()) {
                val o = ph.getJSONObject(i)
                val wl = o.optJSONArray("wmLines")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                photos += PhotoMeta(
                    o.getString("fileName"),
                    o.getLong("takenAt"),
                    o.getString("projectId"),
                    o.getString("relativeDir"),
                    wl
                )
            }
        } catch (e: Exception) {
            // 损坏的元数据文件按空数据对待
        }
    }

    private fun save() {
        val obj = JSONObject()
        val pa = JSONArray()
        projects.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("parentId", p.parentId ?: "")
            o.put("createdAt", p.createdAt)
            pa.put(o)
        }
        val ph = JSONArray()
        photos.forEach { p ->
            val o = JSONObject()
            o.put("fileName", p.fileName)
            o.put("takenAt", p.takenAt)
            o.put("projectId", p.projectId)
            o.put("relativeDir", p.relativeDir)
            val wl = JSONArray()
            p.wmLines.forEach { wl.put(it) }
            o.put("wmLines", wl)
            ph.put(o)
        }
        obj.put("projects", pa)
        obj.put("photos", ph)
        file.parentFile?.mkdirs()
        file.writeText(obj.toString())
    }

    fun childrenOf(parentId: String?): List<ProjectNode> =
        projects.filter { it.parentId == parentId }.sortedBy { it.createdAt }

    fun find(id: String): ProjectNode? = projects.firstOrNull { it.id == id }

    fun photosOf(projectId: String): List<PhotoMeta> =
        photos.filter { it.projectId == projectId }.sortedByDescending { it.takenAt }

    fun createProject(name: String, parentId: String?): ProjectNode {
        val node = ProjectNode(UUID.randomUUID().toString().take(8), name, parentId, System.currentTimeMillis())
        projects += node
        save()
        return node
    }

    fun rename(id: String, newName: String) {
        val idx = projects.indexOfFirst { it.id == id }
        if (idx >= 0) {
            projects[idx] = projects[idx].copy(name = newName)
            save()
        }
    }

    fun descendantIds(id: String): Set<String> {
        val result = mutableSetOf<String>()
        fun walk(cur: String) {
            result += cur
            childrenOf(cur).forEach { walk(it.id) }
        }
        walk(id)
        return result
    }

    fun deleteProject(id: String) {
        val ids = descendantIds(id)
        projects.removeAll { it.id in ids }
        photos.removeAll { it.projectId in ids }
        save()
    }

    fun addPhoto(projectId: String, fileName: String, takenAt: Long, relativeDir: String, wmLines: List<String>) {
        photos += PhotoMeta(fileName, takenAt, projectId, relativeDir, wmLines)
        save()
    }

    fun removePhoto(projectId: String, fileName: String) {
        photos.removeAll { it.projectId == projectId && it.fileName == fileName }
        save()
    }

    /** 从根到该项目的名称链（用于照片目录） */
    fun pathNames(id: String): List<String> {
        val chain = mutableListOf<String>()
        var cur: ProjectNode? = find(id)
        while (cur != null) {
            chain.add(0, cur.name)
            cur = cur.parentId?.let { find(it) }
        }
        return chain
    }

    private fun idChainToRoot(id: String): List<String> {
        val l = mutableListOf<String>()
        var cur: String? = id
        while (cur != null) {
            l.add(cur)
            val n = find(cur) ?: break
            cur = n.parentId
        }
        return l
    }

    /** root 到 pid 之间的相对名称链（不含 root 本身） */
    fun relChainNames(rootId: String, pid: String): List<String> {
        val chain = idChainToRoot(pid)
        val idx = chain.indexOf(rootId)
        if (idx < 0) return emptyList()
        return chain.take(idx).reversed().mapNotNull { find(it)?.name }
    }

    /** 某项目及其全部后代项目的照片，附带相对子路径（ZIP 用） */
    fun descendantsPhotos(rootId: String): List<Pair<PhotoMeta, List<String>>> {
        val result = mutableListOf<Pair<PhotoMeta, List<String>>>()
        descendantIds(rootId).forEach { pid ->
            val rel = relChainNames(rootId, pid)
            photosOf(pid).forEach { result += it to rel }
        }
        return result
    }

    fun photoCountOf(id: String) = photos.count { it.projectId == id }
}
