package com.projectcamera.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.projectcamera.AppData
import com.projectcamera.data.PhotoStore
import com.projectcamera.data.WmSettings
import com.projectcamera.util.Fmt
import com.projectcamera.util.LocInfo
import com.projectcamera.util.LocationHelper
import com.projectcamera.util.StorageAccess
import com.projectcamera.util.Watermark
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CameraScreen(projectId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = AppData.repo
    val project = repo.find(projectId)
    if (project == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val projectName = project.name
    val lifecycleOwner = LocalLifecycleOwner.current

    var wm by remember { mutableStateOf(AppData.settings.load()) }
    var wmOn by remember { mutableStateOf(true) }
    var compress by remember { mutableStateOf(AppData.settings.load().photoCompress) }
    var torchOn by remember { mutableStateOf(false) }
    var facingFront by remember { mutableStateOf(false) }
    var capturing by remember { mutableStateOf(false) }
    var loc by remember { mutableStateOf<LocInfo?>(null) }
    var previewLines by remember { mutableStateOf<List<String>>(emptyList()) }
    var lastShotRelDir by remember { mutableStateOf<String?>(null) }
    var lastShotFile by remember { mutableStateOf<String?>(null) }

    val cameraProvider = remember { ProcessCameraProvider.getInstance(context) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val scope = rememberCoroutineScope()

    var cameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> cameraGranted = granted }

    val locPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scope.launch { loc = LocationHelper.fetch(context) }
    }

    val needLoc = wm.showLocation || wm.showLatLng

    LaunchedEffect(Unit) {
        if (!cameraGranted) cameraPermLauncher.launch(Manifest.permission.CAMERA)
    }
    LaunchedEffect(needLoc) {
        if (needLoc) {
            if (LocationHelper.hasPermission(context)) {
                loc = LocationHelper.fetch(context)
            } else {
                locPermLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
    }
    LaunchedEffect(wmOn, wm, loc) {
        while (wmOn) {
            previewLines = Watermark.lines(projectName, wm, System.currentTimeMillis(), loc)
            delay(1000)
        }
        previewLines = emptyList()
    }

    DisposableEffect(facingFront, cameraGranted) {
        if (!cameraGranted) {
            return@DisposableEffect onDispose { }
        }
        val executor = ContextCompat.getMainExecutor(context)
        val listener = Runnable {
            try {
                val provider = cameraProvider.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val ic = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val selector = if (facingFront) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }
                provider.unbindAll()
                val cam = provider.bindToLifecycle(lifecycleOwner, selector, preview, ic)
                camera = cam
                imageCapture = ic
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        cameraProvider.addListener(listener, executor)
        onDispose {
            try {
                cameraProvider.get().unbindAll()
            } catch (e: Exception) {
            }
        }
    }

    LaunchedEffect(torchOn, camera) {
        try {
            camera?.cameraControl?.enableTorch(torchOn)
        } catch (e: Exception) {
        }
    }

    fun capture() {
        if (capturing) return
        if (!PhotoStore.storageReady(context)) {
            Toast.makeText(
                context,
                "需要「所有文件访问」权限才能保存照片",
                Toast.LENGTH_LONG
            ).show()
            StorageAccess.openSettings(context)
            return
        }
        val ic = imageCapture ?: return
        capturing = true
        val executor = ContextCompat.getMainExecutor(context)
        ic.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        try {
                            val raw = image.toBitmap()
                            val rot = image.imageInfo.rotationDegrees
                            val bmp = if (rot == 0) raw else {
                                val m = Matrix().apply { postRotate(rot.toFloat()) }
                                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                            }
                            val lines = if (wmOn) {
                                Watermark.lines(projectName, wm, System.currentTimeMillis(), loc)
                            } else emptyList()
                            val out = if (wmOn) Watermark.apply(bmp, lines, wm) else bmp
                            val ts = System.currentTimeMillis()
                            val fileName = "IMG_" + Fmt.compactStamp(ts) + ".jpg"
                            val relDir = PhotoStore.relativeDirFor(repo.pathNames(projectId))
                            val quality = if (compress) 85 else 92
                            val saved = PhotoStore.savePhoto(
                                context, out, relDir, fileName, ts, quality
                            )
                            if (saved) {
                                repo.addPhoto(projectId, fileName, ts, relDir, lines)
                                lastShotRelDir = relDir
                                lastShotFile = fileName
                            }
                            saved
                        } finally {
                            image.close()
                        }
                    }
                    capturing = false
                    Toast.makeText(
                        context,
                        if (ok) "已拍摄" else "保存失败",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onError(exc: ImageCaptureException) {
                capturing = false
                Toast.makeText(context, "拍摄失败", Toast.LENGTH_SHORT).show()
            }
        })
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.Close, contentDescription = "退出", tint = Color.White)
            }
            Text(
                projectName,
                Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                color = Color.White,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = { torchOn = !torchOn }) {
                Icon(
                    IconFlash,
                    contentDescription = "闪光灯",
                    tint = if (torchOn) Color(0xFFFFD54F) else Color.White
                )
            }
            IconButton(onClick = { facingFront = !facingFront }) {
                Icon(IconSwitchCamera, contentDescription = "切换镜头", tint = Color.White)
            }
        }

        Column(
            Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(start = 16.dp, top = 56.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0x66000000)
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(7.dp)
                            .background(
                                if (wmOn) Color(0xFF4ADE80) else Color(0xFF9AA0A6),
                                CircleShape
                            )
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        if (wmOn) "水印已开" else "水印已关",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = wmOn, onCheckedChange = { wmOn = it })
                }
            }
            Spacer(Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0x66000000)
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(7.dp)
                            .background(
                                if (compress) Color(0xFF4ADE80) else Color(0xFF9AA0A6),
                                CircleShape
                            )
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        if (compress) "压缩已开" else "压缩已关",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.width(8.dp))
                    Switch(
                        checked = compress,
                        onCheckedChange = {
                            compress = it
                            AppData.settings.save(wm.copy(photoCompress = it))
                        }
                    )
                }
            }
        }

        if (wmOn && previewLines.isNotEmpty()) {
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 16.dp, bottom = 150.dp)
            ) {
                previewLines.forEach { line ->
                    Text(
                        line,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        style = TextStyle(
                            shadow = Shadow(
                                color = Color.Black,
                                offset = androidx.compose.ui.geometry.Offset(0f, 2f),
                                blurRadius = 6f
                            )
                        )
                    )
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 28.dp, vertical = 22.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                shape = RoundedCornerShape(13.dp),
                border = BorderStroke(2.dp, Color.White),
                modifier = Modifier.size(52.dp)
            ) {
                PhotoThumb(lastShotRelDir, lastShotFile, Modifier.fillMaxSize())
            }

            Surface(
                shape = CircleShape,
                border = BorderStroke(3.dp, Color.White),
                modifier = Modifier
                    .size(72.dp)
                    .clickable(enabled = !capturing, onClick = { capture() })
            ) {
                Box(Modifier.fillMaxSize().padding(6.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = if (capturing) Color(0x66FFFFFF) else Color.White,
                        modifier = Modifier.fillMaxSize()
                    ) {}
                }
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = Color.White,
                modifier = Modifier.clickable(onClick = onBack)
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF101828), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("完成", color = Color(0xFF101828), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }
        }

        if (!cameraGranted) {
            Column(
                Modifier
                    .align(Alignment.Center)
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("需要相机权限才能拍摄", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "拍摄的照片将保存在项目目录中",
                    color = Color(0xFFB4BAC6),
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(16.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable {
                        cameraPermLauncher.launch(Manifest.permission.CAMERA)
                    }
                ) {
                    Text(
                        "重新授权",
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
