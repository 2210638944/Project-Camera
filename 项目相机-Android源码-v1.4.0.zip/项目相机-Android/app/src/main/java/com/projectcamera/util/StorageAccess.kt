package com.projectcamera.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast

/** 存储根目录权限引导：Android 11+ 需要「所有文件访问」，Android 10 及以下走运行时存储权限 */
object StorageAccess {

    const val MANAGE_ACTION =
        "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION"

    fun needsManageAccess(context: Context): Boolean =
        Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()

    fun openSettings(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= 30) {
            Intent(MANAGE_ACTION).apply {
                setData(Uri.parse("package:${context.packageName}"))
            }
        } else {
            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "请在系统设置中开启「所有文件访问」权限后重试",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
