package com.projectcamera.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.projectcamera.AppData
import com.projectcamera.BuildConfig
import com.projectcamera.data.PhotoStore
import com.projectcamera.data.WmSettings
import com.projectcamera.util.ShareExport

private val POSITIONS = listOf("左下角", "右下角", "左上角", "右上角")
private val FONT_SIZES = listOf("小", "中", "大")

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = AppData.settings
    var s by remember { mutableStateOf(store.load()) }
    var posOpen by remember { mutableStateOf(false) }
    var fontOpen by remember { mutableStateOf(false) }

    fun update(new: WmSettings) {
        s = new
        store.save(new)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        AppTopBar("设置", onBack = onBack)

        SectionLabel("水印参数")
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
        ) {
            Column {
                SwitchRow("项目名称", "在照片上标注所属项目", s.showProject) { update(s.copy(showProject = it)) }
                SwitchRow("日期时间", "格式：2026-09-30 09:41:25", s.showTime) { update(s.copy(showTime = it)) }
                SwitchRow("位置信息", "显示街道 / 地名，需定位权限", s.showLocation) { update(s.copy(showLocation = it)) }
                SwitchRow("经纬度", "显示精确坐标，需定位权限", s.showLatLng) { update(s.copy(showLatLng = it)) }
            }
        }

        SectionLabel("水印样式")
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
        ) {
            Column {
                ValueRow("水印位置", POSITIONS[s.position]) { posOpen = true }
                ValueRow("字号", FONT_SIZES[s.fontSize]) { fontOpen = true }
                SwitchRow("文字阴影", "防止浅色背景看不清", s.shadow) { update(s.copy(shadow = it)) }
            }
        }

        SectionLabel("通用")
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
        ) {
            Column {
                ValueRow("存储目录", "存储根目录/项目相机/") {
                    ShareExport.openDir(context, PhotoStore.rootDir(context))
                }
                ValueRow("版本", BuildConfig.VERSION_NAME) {}
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (posOpen) {
        ChoiceDialog(
            title = "水印位置",
            options = POSITIONS,
            selected = s.position,
            onCancel = { posOpen = false },
            onPick = { idx ->
                update(s.copy(position = idx))
                posOpen = false
            }
        )
    }
    if (fontOpen) {
        ChoiceDialog(
            title = "字号",
            options = FONT_SIZES,
            selected = s.fontSize,
            onCancel = { fontOpen = false },
            onPick = { idx ->
                update(s.copy(fontSize = idx))
                fontOpen = false
            }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        Modifier.padding(start = 18.dp, top = 18.dp, bottom = 8.dp),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun SwitchRow(label: String, desc: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onToggle(!checked) }
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Text(
                desc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}

@Composable
private fun ValueRow(label: String, value: String, onClick: () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.weight(1f))
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(4.dp))
        Icon(
            Icons.Default.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: Int,
    onCancel: () -> Unit,
    onPick: (Int) -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                options.forEachIndexed { idx, opt ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(idx) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = idx == selected, onClick = { onPick(idx) })
                        Spacer(Modifier.width(8.dp))
                        Text(opt, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onCancel) { Text("取消") }
        }
    )
}
