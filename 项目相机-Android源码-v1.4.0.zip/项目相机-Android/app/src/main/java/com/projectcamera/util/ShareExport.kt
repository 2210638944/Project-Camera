package com.projectcamera.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.core.content.FileProvider
import com.projectcamera.data.PhotoStore
import com.projectcamera.data.ProjectDocsProvider
import java.io.File

object ShareExport {
    const val AUTHORITY = PhotoStore.AUTHORITY

    fun shareFile(context: Context, file: File, mime: String) {
        val exportDir = File(context.cacheDir, "export").apply { mkdirs() }
        val target = File(exportDir, file.name)
        try {
            file.copyTo(target, overwrite = true)
        } catch (e: Exception) {
            Toast.makeText(context, "文件复制失败", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = FileProvider.getUriForFile(context, AUTHORITY, target)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "分享到"))
        } catch (e: Exception) {
            Toast.makeText(context, "没有可用的分享应用", Toast.LENGTH_SHORT).show()
        }
    }

    fun sharePhoto(context: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "分享照片"))
        } catch (e: Exception) {
            Toast.makeText(context, "没有可用的分享应用", Toast.LENGTH_SHORT).show()
        }
    }

    /** 导出到根目录项目相机子目录，返回可打开的 content uri */
    fun exportToDir(context: Context, subDir: String, file: File, mime: String): Uri? {
        val out = PhotoStore.exportToRoot(context, subDir, file.name, mime, file) ?: return null
        return try {
            FileProvider.getUriForFile(context, AUTHORITY, out)
        } catch (e: Exception) {
            null
        }
    }

    fun openFile(context: Context, uri: Uri, mime: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "没有可打开该文件的应用", Toast.LENGTH_SHORT).show()
        }
    }

    /** 用系统自带文件管理器打开目录：优先直达，失败则用系统文档界面定位 */
    fun openDir(context: Context, dir: File) {
        try {
            if (!dir.exists()) dir.mkdirs()
        } catch (e: Exception) {
        }
        if (dir.exists()) {
            // 1) 系统文件管理器直接打开该目录
            try {
                val uri = FileProvider.getUriForFile(context, AUTHORITY, dir)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "resource/folder")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(intent)
                return
            } catch (e: Exception) {
                // 继续走兜底
            }
        }
        // 2) 系统文件管理器（DocumentsUI）定位到 项目相机 目录
        try {
            val ext = Environment.getExternalStorageDirectory().absolutePath
            val rel = dir.absolutePath.removePrefix(ext).trim('/')
            val docId = if (rel == PhotoStore.BASE_DIR) {
                ProjectDocsProvider.ROOT_ID
            } else {
                rel.removePrefix(PhotoStore.BASE_DIR).trim('/')
            }
            val uri = DocumentsContract.buildDocumentUri(ProjectDocsProvider.AUTHORITY, docId)
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "没有可打开目录的应用", Toast.LENGTH_SHORT).show()
        }
    }
}
