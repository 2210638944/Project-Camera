package com.projectcamera.data

import android.content.Context

data class WmSettings(
    val showProject: Boolean = true,
    val showTime: Boolean = true,
    val showLocation: Boolean = false,
    val showLatLng: Boolean = false,
    val shadow: Boolean = true,
    val position: Int = 0, // 0 左下 1 右下 2 左上 3 右上
    val fontSize: Int = 1, // 0 小 1 中 2 大
    val photoCompress: Boolean = true // 拍照压缩（质量 85，体积更小）
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): WmSettings = WmSettings(
        prefs.getBoolean("wm_project", true),
        prefs.getBoolean("wm_time", true),
        prefs.getBoolean("wm_location", false),
        prefs.getBoolean("wm_latlng", false),
        prefs.getBoolean("wm_shadow", true),
        prefs.getInt("wm_position", 0),
        prefs.getInt("wm_font", 1),
        prefs.getBoolean("photo_compress", true)
    )

    fun save(s: WmSettings) {
        prefs.edit()
            .putBoolean("wm_project", s.showProject)
            .putBoolean("wm_time", s.showTime)
            .putBoolean("wm_location", s.showLocation)
            .putBoolean("wm_latlng", s.showLatLng)
            .putBoolean("wm_shadow", s.shadow)
            .putInt("wm_position", s.position)
            .putInt("wm_font", s.fontSize)
            .putBoolean("photo_compress", s.photoCompress)
            .apply()
    }
}
