package com.projectcamera.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Fmt {
    private val dateTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
    private val compact = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    private val short = SimpleDateFormat("MM-dd", Locale.CHINA)

    fun dateTime(t: Long) = dateTime.format(Date(t))
    fun compactStamp(t: Long) = compact.format(Date(t))
    fun shortDate(t: Long) = short.format(Date(t))
}
