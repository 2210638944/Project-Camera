package com.projectcamera

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.projectcamera.data.ProjectRepository
import com.projectcamera.data.SettingsStore
import com.projectcamera.ui.CameraScreen
import com.projectcamera.ui.HomeScreen
import com.projectcamera.ui.PhotoViewerScreen
import com.projectcamera.ui.ProjectCameraTheme
import com.projectcamera.ui.ProjectScreen
import com.projectcamera.ui.SettingsScreen

object AppData {
    lateinit var repo: ProjectRepository
    lateinit var settings: SettingsStore
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppData.repo = ProjectRepository(applicationContext)
        AppData.settings = SettingsStore(applicationContext)
        setContent {
            ProjectCameraTheme {
                AppRoot()
            }
        }
    }
}

sealed class Screen {
    object Home : Screen()
    data class Project(val id: String) : Screen()
    data class Camera(val id: String) : Screen()
    data class Viewer(val id: String, val startIndex: Int) : Screen()
    object Settings : Screen()
}

@Composable
fun AppRoot() {
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    var dataVersion by remember { mutableIntStateOf(0) }
    fun bump() {
        dataVersion++
    }

    BackHandler(enabled = stack.size > 1) {
        stack.removeAt(stack.lastIndex)
    }

    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        when (val s = stack.last()) {
            Screen.Home -> HomeScreen(
                dataVersion = dataVersion,
                onDataChanged = { bump() },
                onOpenProject = { stack.add(Screen.Project(it)) },
                onOpenSettings = { stack.add(Screen.Settings) }
            )
            is Screen.Project -> ProjectScreen(
                projectId = s.id,
                dataVersion = dataVersion,
                onDataChanged = { bump() },
                onBack = { stack.removeAt(stack.lastIndex) },
                onOpenCamera = { stack.add(Screen.Camera(s.id)) },
                onOpenProject = { stack.add(Screen.Project(it)) },
                onOpenViewer = { i -> stack.add(Screen.Viewer(s.id, i)) }
            )
            is Screen.Camera -> CameraScreen(
                projectId = s.id,
                onBack = { stack.removeAt(stack.lastIndex) }
            )
            is Screen.Viewer -> PhotoViewerScreen(
                projectId = s.id,
                startIndex = s.startIndex,
                dataVersion = dataVersion,
                onDataChanged = { bump() },
                onBack = { stack.removeAt(stack.lastIndex) }
            )
            Screen.Settings -> SettingsScreen(
                onBack = { stack.removeAt(stack.lastIndex) }
            )
        }
    }
}
