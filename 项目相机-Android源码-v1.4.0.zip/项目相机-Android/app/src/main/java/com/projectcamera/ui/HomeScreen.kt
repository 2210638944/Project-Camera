package com.projectcamera.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.projectcamera.AppData
import com.projectcamera.ProjectNode
import com.projectcamera.util.Fmt

@Composable
fun HomeScreen(
    dataVersion: Int,
    onDataChanged: () -> Unit,
    onOpenProject: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val repo = AppData.repo
    val projects = remember(dataVersion) { repo.childrenOf(null) }

    var showCreate by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }
    var menuTarget by remember { mutableStateOf<ProjectNode?>(null) }
    var renameTarget by remember { mutableStateOf<ProjectNode?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<ProjectNode?>(null) }
    var exportTarget by remember { mutableStateOf<ProjectNode?>(null) }
    var exportMode by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            AppTopBar(
                title = "项目相机",
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "设置")
                    }
                }
            )
            if (projects.isEmpty()) {
                EmptyState(
                    title = "还没有项目",
                    body = "点击右下角 ＋ 创建你的第一个项目"
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(projects, key = { it.id }) { p ->
                        ProjectCard(
                            p,
                            onClick = { onOpenProject(p.id) },
                            onLongClick = { menuTarget = p }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showCreate = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(18.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "新建项目")
        }
    }

    if (showCreate) {
        CreateProjectDialog(
            value = nameInput,
            onValueChange = { nameInput = it },
            onCancel = { showCreate = false; nameInput = "" },
            onConfirm = {
                val n = nameInput.trim()
                if (n.isNotEmpty()) {
                    repo.createProject(n, null)
                    onDataChanged()
                }
                showCreate = false
                nameInput = ""
            }
        )
    }

    menuTarget?.let { p ->
        ProjectMenuDialog(
            project = p,
            onDismiss = { menuTarget = null },
            onRename = {
                renameTarget = p
                renameValue = p.name
            },
            onExport = { mode ->
                exportTarget = p
                exportMode = mode
            },
            onDelete = { deleteTarget = p }
        )
    }

    renameTarget?.let { p ->
        RenameDialog(
            initial = renameValue,
            onValueChange = { renameValue = it },
            onCancel = { renameTarget = null },
            onConfirm = {
                val n = renameValue.trim()
                if (n.isNotEmpty()) {
                    repo.rename(p.id, n)
                    onDataChanged()
                }
                renameTarget = null
            }
        )
    }

    deleteTarget?.let { p ->
        DeleteConfirmDialog(
            title = "删除项目？",
            body = "将删除「${p.name}」及其中 ${repo.photoCountOf(p.id)} 张照片（含全部子项目）。此操作不可恢复。",
            onCancel = { deleteTarget = null },
            onConfirm = {
                repo.deleteProject(p.id)
                onDataChanged()
                deleteTarget = null
            }
        )
    }

    exportTarget?.let { p ->
        exportMode?.let { mode ->
            ExportFlowDialog(projectId = p.id, mode = mode, onClose = {
                exportMode = null
                exportTarget = null
            })
        }
    }
}

@Composable
fun EmptyState(title: String, body: String) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
            modifier = Modifier.size(56.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    IconFolder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProjectCard(
    project: ProjectNode,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val repo = AppData.repo
    val photos = remember(project.id) { repo.photosOf(project.id) }
    val cover = photos.firstOrNull()
    val updateTime = cover?.takenAt ?: project.createdAt

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .clip(RoundedCornerShape(16.dp)),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(88.dp)) {
                PhotoThumb(cover?.relativeDir, cover?.fileName, Modifier.fillMaxSize())
            }
            Column(Modifier.padding(horizontal = 10.dp, vertical = 10.dp)) {
                Text(
                    project.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    "${photos.size} 张 · ${Fmt.shortDate(updateTime)} 更新",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
