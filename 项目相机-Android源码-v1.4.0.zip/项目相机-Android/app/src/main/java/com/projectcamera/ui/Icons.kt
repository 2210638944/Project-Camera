package com.projectcamera.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

private fun vector(name: String, pathStr: String): ImageVector =
    ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).addPath(
        pathData = PathParser().parsePathString(pathStr).toNodes(),
        fill = null,
        stroke = SolidColor(Color.Black),
        strokeLineWidth = 1.9f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    ).build()

val IconCamera: ImageVector by lazy {
    vector(
        "camera",
        "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" +
            "M12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8"
    )
}

val IconFolder: ImageVector by lazy {
    vector(
        "folder",
        "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"
    )
}

val IconFolderPlus: ImageVector by lazy {
    vector(
        "folder_plus",
        "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" +
            "M12 11v6M9 14h6"
    )
}

val IconFlash: ImageVector by lazy {
    vector("flash", "M13 2 3 14h9l-1 8 10-12h-9l1-8z")
}

val IconSwitchCamera: ImageVector by lazy {
    vector(
        "switch_camera",
        "M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3"
    )
}

val IconLocation: ImageVector by lazy {
    vector(
        "location",
        "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" +
            "M12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6"
    )
}

val IconZip: ImageVector by lazy {
    vector("zip", "M21 8v13H3V8M1 3h22v5H1zM10 12h4")
}

val IconFile: ImageVector by lazy {
    vector(
        "file",
        "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" +
            "M14 2v6h6"
    )
}

val IconDownload: ImageVector by lazy {
    vector(
        "download",
        "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"
    )
}

val IconImage: ImageVector by lazy {
    vector(
        "image",
        "M3 3h18v18H3zM8.5 10a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM21 15l-5-5L5 21"
    )
}

val IconClock: ImageVector by lazy {
    vector(
        "clock",
        "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2"
    )
}
