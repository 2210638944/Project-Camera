package com.projectcamera

data class ProjectNode(
    val id: String,
    val name: String,
    val parentId: String?,
    val createdAt: Long
)

data class PhotoMeta(
    val fileName: String,
    val takenAt: Long,
    val projectId: String,
    val relativeDir: String,
    val wmLines: List<String>
)
