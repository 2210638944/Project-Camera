package com.projectcamera.util

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.projectcamera.PhotoMeta
import com.projectcamera.data.PhotoStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Exporter {

    data class PhotoItem(val meta: PhotoMeta, val subPath: List<String>)

    suspend fun generatePdf(
        context: Context,
        projectName: String,
        photos: List<PhotoMeta>,
        out: File,
        onProgress: (done: Int, total: Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        val total = photos.size
        val doc = PdfDocument()
        photos.forEachIndexed { i, p ->
            val bytes = PhotoStore.openStream(context, p.relativeDir, p.fileName)?.use { it.readBytes() }
            val bmp = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            if (bmp != null) {
                val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, i + 1).create())
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val margin = 36f
                val footerH = 30f
                val availW = 595f - margin * 2
                val availH = 842f - margin * 2 - footerH
                val scale = minOf(availW / bmp.width, availH / bmp.height)
                val dw = bmp.width * scale
                val dh = bmp.height * scale
                val dx = (595f - dw) / 2f
                val dy = (842f - footerH - dh) / 2f
                canvas.drawBitmap(bmp, null, RectF(dx, dy, dx + dw, dy + dh), Paint(Paint.FILTER_BITMAP_FLAG))
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.GRAY
                    textSize = 9f
                }
                canvas.drawText("$projectName · 第 ${i + 1} / $total 页", 36f, 842f - 16f, paint)
                doc.finishPage(page)
            }
            onProgress(i + 1, total)
        }
        try {
            FileOutputStream(out).use { doc.writeTo(it) }
        } finally {
            doc.close()
        }
    }

    suspend fun generateZip(
        context: Context,
        rootProjectName: String,
        items: List<PhotoItem>,
        out: File,
        onProgress: (done: Int, total: Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        val total = items.size
        val root = PhotoStore.sanitize(rootProjectName)
        ZipOutputStream(FileOutputStream(out)).use { zos ->
            items.forEachIndexed { i, item ->
                val rel = item.subPath.joinToString("/") { PhotoStore.sanitize(it) }
                val entryName = if (rel.isEmpty()) {
                    "$root/${item.meta.fileName}"
                } else {
                    "$root/$rel/${item.meta.fileName}"
                }
                PhotoStore.openStream(context, item.meta.relativeDir, item.meta.fileName)?.use { ins ->
                    zos.putNextEntry(ZipEntry(entryName))
                    ins.copyTo(zos)
                    zos.closeEntry()
                }
                onProgress(i + 1, total)
            }
        }
    }
}
