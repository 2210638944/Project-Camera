package com.projectcamera.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.projectcamera.AppData
import com.projectcamera.ProjectNode
import com.projectcamera.data.PhotoStore
import com.projectcamera.util.Exporter
import com.projectcamera.util.Fmt
import com.projectcamera.util.ShareExport
import com.projectcamera.util.StorageAccess
import kotlinx.coroutines.launch
import java.io.File
import java.util.Date
import java.util.Locale

@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(54.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
            }
        } else {
            Spacer(Modifier.width(6.dp))
        }
        Text(
            title,
            Modifier
                .weight(1f)
                .padding(start = 4.dp),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        actions()
    }
}

@Composable
fun PhotoThumb(relDir: String?, fileName: String?, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bmp by produceState<Bitmap?>(initialValue = null, relDir, fileName) {
        value = if (relDir != null && fileName != null) {
            PhotoStore.loadBitmap(context, relDir, fileName, 512)
        } else null
    }
    if (bmp != null) {
        Image(
            bitmap = bmp!!.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant))
    }
}

@Composable
fun CreateProjectDialog(
    value: String,
    onValueChange: (String) -> Unit,
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
    title: String = "新建项目"
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    label = { Text("项目名称") },
                    placeholder = { Text("如：A座装修工程") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text("项目内可继续创建子项目，层级不限。", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                enabled = value.trim().isNotEmpty()
            ) { Text("创建") }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text("取消") }
        }
    )
}

@Composable
fun RenameDialog(
    initial: String,
    onValueChange: (String) -> Unit,
    onCancel: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("重命名", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = initial,
                onValueChange = onValueChange,
                label = { Text("项目名称") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = initial.trim().isNotEmpty()) { Text("确定") }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text("取消") }
        }
    )
}

@Composable
fun DeleteConfirmDialog(
    title: String,
    body: String,
    onCancel: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(body) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("删除", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text("取消") }
        }
    )
}

@Composable
fun ProjectMenuDialog(
    project: ProjectNode,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onExport: (String) -> Unit,
    onDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(project.name, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                MenuItemRow(Icons.Default.Edit, "重命名", null) { onDismiss(); onRename() }
                MenuItemRow(Icons.Default.Share, "生成 PDF", "仅本项目直接照片 · 一页一张") { onDismiss(); onExport("pdf") }
                MenuItemRow(IconZip, "生成 ZIP", "含全部子项目的照片") { onDismiss(); onExport("zip") }
                MenuItemRow(Icons.Default.Delete, "删除项目", null, danger = true) { onDismiss(); onDelete() }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@Composable
private fun MenuItemRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    desc: String?,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text(label, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            if (desc != null) {
                Text(
                    desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/** 生成 PDF/ZIP 的完整流程弹窗：进度 → 完成（分享/导出） → 导出成功 */
@Composable
fun ExportFlowDialog(
    projectId: String,
    mode: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val repo = AppData.repo
    val project = repo.find(projectId)
    val isPdf = mode == "pdf"
    val mime = if (isPdf) "application/pdf" else "application/zip"
    val subDir = if (isPdf) "PDF" else "ZIP"

    var phase by remember { mutableStateOf("gen") } // gen | result | exported | empty
    var progress by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var outFile by remember { mutableStateOf<File?>(null) }
    var exportedUri by remember { mutableStateOf<android.net.Uri?>(null) }

    LaunchedEffect(Unit) {
        val name = project?.name ?: "项目"
        val ts = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val f = File(
            File(context.cacheDir, "gen"),
            "${PhotoStore.sanitize(name)}_$ts.${if (isPdf) "pdf" else "zip"}"
        )
        f.parentFile?.mkdirs()
        if (isPdf) {
            val photos = repo.photosOf(projectId)
            if (photos.isEmpty()) {
                phase = "empty"
                return@LaunchedEffect
            }
            Exporter.generatePdf(context, name, photos, f) { d, t -> progress = d; total = t }
        } else {
            val items = repo.descendantsPhotos(projectId).map { Exporter.PhotoItem(it.first, it.second) }
            if (items.isEmpty()) {
                phase = "empty"
                return@LaunchedEffect
            }
            Exporter.generateZip(context, name, items, f) { d, t -> progress = d; total = t }
        }
        outFile = f
        phase = "result"
    }

    when (phase) {
        "gen" -> AlertDialog(
            onDismissRequest = {},
            title = { Text("正在生成 ${if (isPdf) "PDF" else "ZIP"}…", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    LinearProgressIndicator(
                        progress = { if (total > 0) progress.toFloat() / total else 0f },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "已处理 $progress / $total 个文件",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = onClose) { Text("取消") }
            }
        )

        "empty" -> AlertDialog(
            onDismissRequest = onClose,
            title = { Text("无法生成", fontWeight = FontWeight.Bold) },
            text = { Text("该项目没有照片。") },
            confirmButton = {
                TextButton(onClick = onClose) { Text("知道了") }
            }
        )

        "result" -> AlertDialog(
            onDismissRequest = onClose,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = GreenOk)
                    Spacer(Modifier.width(8.dp))
                    Text("${if (isPdf) "PDF" else "ZIP"} 生成成功", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                val f = outFile
                if (f != null) {
                    Column {
                        Text(f.name, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${String.format(Locale.US, "%.1f", f.length() / 1024f / 1024f)} MB · $total 个文件",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        outFile?.let { ShareExport.shareFile(context, it, mime) }
                    }
                ) { Text("分享") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        val f = outFile ?: return@TextButton
                        if (!PhotoStore.storageReady(context)) {
                            StorageAccess.openSettings(context)
                            return@TextButton
                        }
                        val uri = ShareExport.exportToDir(context, subDir, f, mime)
                        if (uri != null) {
                            exportedUri = uri
                            phase = "exported"
                        } else {
                            Toast.makeText(context, "导出失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) { Text("导出到目录") }
            }
        )

        "exported" -> AlertDialog(
            onDismissRequest = onClose,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = GreenOk)
                    Spacer(Modifier.width(8.dp))
                    Text("导出成功", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        "已写入 存储根目录/项目相机/$subDir/",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        outFile?.name ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Row {
                    TextButton(
                        onClick = {
                            ShareExport.openDir(context, File(PhotoStore.rootDir(context), subDir))
                        }
                    ) { Text("打开目录") }
                    TextButton(
                        onClick = {
                            val u = exportedUri
                            val f = outFile
                            if (u != null && f != null) ShareExport.openFile(context, u, mime)
                        }
                    ) { Text("打开文件") }
                }
            },
            dismissButton = {
                TextButton(onClick = onClose) { Text("完成") }
            }
        )
    }
}
