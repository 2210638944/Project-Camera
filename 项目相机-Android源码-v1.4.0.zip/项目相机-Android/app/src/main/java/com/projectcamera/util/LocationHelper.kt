package com.projectcamera.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

data class LocInfo(val address: String?, val latLng: String)

object LocationHelper {

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED

    suspend fun fetch(context: Context): LocInfo? = withContext(Dispatchers.IO) {
        if (!hasPermission(context)) return@withContext null
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return@withContext null
        val loc: Location = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        ).mapNotNull { provider ->
            try { lm.getLastKnownLocation(provider) } catch (e: Exception) { null }
        }.maxByOrNull { it.time } ?: return@withContext null

        val address = try {
            val gc = Geocoder(context, Locale.CHINA)
            gc.getFromLocation(loc.latitude, loc.longitude, 1)
                ?.firstOrNull()
                ?.getAddressLine(0)
        } catch (e: Exception) {
            null
        }
        val latLng = String.format(Locale.US, "%.4f°N, %.4f°E", loc.latitude, loc.longitude)
        LocInfo(address, latLng)
    }
}
